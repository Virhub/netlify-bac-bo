import time
import random
import json
import requests
import telebot
from datetime import datetime
from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup
import bd


api_key = '7743436461:AAFZgoVlC4LxrmmJ4JmPyfB_HUkzxZQjRSU' # Neste campo tenho que colocar a API do BotFather!
chat_id = '-1002285666433'

bot = telebot.TeleBot(token=api_key)

def ALERT_GALE1():
    h = datetime.now().hour
    m = datetime.now().minute + 1
    s = datetime.now().second
    if h <= 9:
        h = f'0{h}'
    if m <= 9:
        m = f'0{m}'
    if s <= 9:
        s = f'0{s}'
    message_id = bot.send_message(chat_id=chat_id, text=f'''
🔍 Possivel Entrada Detectada''').message_id
    bd.message_ids1 = message_id
    time.sleep(15)
    bd.message_delete1 = True

while True:
    h = datetime.now().hour
    m = datetime.now().minute+4
    s = datetime.now().second
    if h <= 9:
        h =  f'0{h}'
    if m <= 9:
        m = f'0{m}'
    if s <= 9:
        s = f'0{s}'
    print(f'{h}:{m}:{s}')

    for i in range (25):
       normal_multiplier = random.randint(5,10)
       turbo_multiplier = random.randint(3,8)

    def button_link():

            markup = InlineKeyboardMarkup()

            markup.row_width = 2

            markup.add(InlineKeyboardButton(text=f"JOGUE AQUI ", url="https://games.elephantbet.co.ao/LaunchGame"))
            return markup                      

    dados = bot.send_message(chat_id=chat_id, text=(f'''                                               
🤑 OPORTUNIDADE IDENTIFICADA
100% DE ACERTO
                                                                                                
🐯  Fortune Tiger
🖥️  Site: ELEPHANTBET
⏰ Validade: 4 𝙢𝙞𝙣𝙪𝙩𝙤𝙨

👉  {normal_multiplier}x 𝙉𝙤𝙧𝙢𝙖𝙡
⚡  {turbo_multiplier}x Turbo
🚥  Intercalando                                                                                                                                                                                                           

  '''),
                reply_markup=button_link()) #acima é a mensagem que será exibida no telegram!
    time.sleep(240)# Aqui é a duração do sinal no caso é 4 minutos, 240 segundos!
    bot.send_message(chat_id=chat_id, text=(f'''
🟢🟢🟢 GREEN 🟢🟢🟢
    '''),
   )
    
    
    time.sleep(60)#60
    #ALERT_GALE1()
    time.sleep(10)#10
    
    time.sleep(50)#50


